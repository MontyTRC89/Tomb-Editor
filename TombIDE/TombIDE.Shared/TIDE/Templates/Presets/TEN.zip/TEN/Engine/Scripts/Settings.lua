-- TombEngine settings file
-- WARNING: Bad values could make your game unplayable; please follow reference guide attentively.

-- Intro image is a splash screen which appears before actual loading screen.
-- If you don't want it to appear, just remove this line.

TEN.Flow.SetIntroImagePath("Screens\\main.jpg")

-- Set overall amount of secrets in game.
-- If set to 0, secrets won't be displayed in statistics.
TEN.Flow.SetTotalSecretCount(5)

-- Enable/Disable Point Filter (square, unsmoothed pixels).
TEN.Flow.EnablePointFilter(false)

-- Enable/Disable saving and loading of savegames.
TEN.Flow.EnableLoadSave(true)

-- Disable/enable flycheat globally
TEN.Flow.EnableFlyCheat(true)

-- Disable/enable Lara drawing in title level
TEN.Flow.EnableLaraInTitle(false)

-- Disable/enable level selection in title level
TEN.Flow.EnableLevelSelect(false)

-- Disable/enable mass pickup (collect all pickups at once)
TEN.Flow.EnableMassPickup(true)

-- Error handling mode
local settings = TEN.Flow.Settings()
settings.errorMode = TEN.Flow.ErrorMode.WARN
TEN.Flow.SetSettings(settings)

local anims = TEN.Flow.Animations()

-- Lara will perform extra animations using crawlspaces
anims.crawlExtended = true

-- Lara rolls while crouching
anims.crouchRoll = true

-- Lara enters a crawlspace with a dive jump
anims.crawlspaceSwandive = true

-- Lara climbs on diagonal monkeyswing. Not yet implemented
anims.overhangClimb = false

-- Lara slides on slopes freely and in any direction. Not yet implemented
anims.slideExtended = false

-- Lara makes a sprint jump while sprinting (TRAOD style)
anims.sprintJump = false

-- Lara will perform an idle pose after 30 seconds of player inactivity
anims.pose = false

-- Lara will perform extra animations on ledges (LAU style)
anims.ledgeJumps = false

TEN.Flow.SetAnimations(anims)
