-- Place in this Lua script all the levels of your game
-- Title is mandatory and must be the first level.

--------------------------------------------------

-- Title level

title = TEN.Flow.Level()

title.ambientTrack = "108"
title.levelFile = "Data\\title.ten"
title.scriptFile = "Scripts\\Levels\\title.lua"
title.loadScreenFile = "Screens\\Main.png"

TEN.Flow.AddLevel(title)

--------------------------------------------------
