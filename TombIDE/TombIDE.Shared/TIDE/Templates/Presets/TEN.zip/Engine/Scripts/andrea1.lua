dofile("Scripts/Constants.lua")
local Util = require("Util")
Util.ShortenTENCalls()

-- Test level script file
LevelFuncs.OnLoad = function() end
LevelFuncs.OnSave = function() end
LevelFuncs.OnEnd = function() end

local currentX = 0.0
local currentY = 0.0

LevelFuncs.OnControlPhase = function()

end
