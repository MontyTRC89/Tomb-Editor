local RingInventory = require("Engine.RingInventory.Inventory")
local PhotoMode = require("Engine.PhotoMode.PhotoMode")