-- Title script file

local Util = require("Util")
Util.ShortenTENCalls()

LevelFuncs.OnLoad = function() end
LevelFuncs.OnSave = function() end
LevelFuncs.OnEnd = function() end

LevelFuncs.OnControlPhase = function() end