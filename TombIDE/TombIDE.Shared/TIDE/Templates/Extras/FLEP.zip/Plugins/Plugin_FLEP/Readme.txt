Install instructions:
1) Launch NG Center
2) Go to [Plugins]
3) Click on [Install New Plugin] and select this folder
